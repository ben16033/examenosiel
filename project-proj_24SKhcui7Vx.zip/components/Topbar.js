function Topbar({ user, onToggleSidebar }) {
  try {
    const [showMenu, setShowMenu] = React.useState(false);

    return (
      <div className="bg-white shadow-sm border-b border-gray-200 fixed top-0 right-0 left-0 z-40" data-name="topbar" data-file="components/Topbar.js">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-4">
            <button onClick={onToggleSidebar} className="p-2 hover:bg-gray-100 rounded-lg">
              <div className="icon-menu text-xl text-gray-700"></div>
            </button>
            <h2 className="text-xl font-semibold text-gray-800">Sistema de Administración</h2>
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-gray-100 rounded-lg relative">
              <div className="icon-bell text-xl text-gray-700"></div>
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>

            <div className="relative">
              <button onClick={() => setShowMenu(!showMenu)} className="flex items-center gap-3 hover:bg-gray-100 rounded-full p-2 pr-4">
                <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full" />
                <div className="text-left">
                  <p className="text-sm font-semibold text-gray-800">{user.name}</p>
                  <p className="text-xs text-gray-500 capitalize">{user.role}</p>
                </div>
              </button>

              {showMenu && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-2">
                  <button className="w-full px-4 py-2 text-left hover:bg-gray-50 flex items-center gap-2">
                    <div className="icon-user text-base text-gray-600"></div>
                    <span className="text-sm">Mi Perfil</span>
                  </button>
                  <button className="w-full px-4 py-2 text-left hover:bg-gray-50 flex items-center gap-2">
                    <div className="icon-settings text-base text-gray-600"></div>
                    <span className="text-sm">Configuración</span>
                  </button>
                  <hr className="my-2" />
                  <button onClick={logout} className="w-full px-4 py-2 text-left hover:bg-gray-50 flex items-center gap-2 text-red-600">
                    <div className="icon-log-out text-base"></div>
                    <span className="text-sm">Cerrar Sesión</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('Topbar component error:', error);
    return null;
  }
}