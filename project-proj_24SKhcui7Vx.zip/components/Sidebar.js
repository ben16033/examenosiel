function Sidebar({ isOpen, userRole }) {
  try {
    const [openMenus, setOpenMenus] = React.useState({});

    const toggleMenu = (menuName) => {
      setOpenMenus(prev => ({ ...prev, [menuName]: !prev[menuName] }));
    };

    const menuItems = [
      { name: 'Dashboard', icon: 'layout-dashboard', link: 'dashboard.html' },
      { 
        name: 'Usuarios', 
        icon: 'users', 
        submenu: [
          { name: 'Lista de Usuarios', link: '#' },
          { name: 'Roles', link: '#' },
          { name: 'Permisos', link: '#' }
        ]
      },
      { 
        name: 'Reportes', 
        icon: 'chart-bar', 
        submenu: [
          { name: 'Ventas', link: '#' },
          { name: 'Análisis', link: '#' }
        ]
      },
      { name: 'Configuración', icon: 'settings', link: '#' }
    ];

    if (!isOpen) return null;

    return (
      <div className="sidebar fixed left-0 top-0 h-screen text-white pt-4 z-30" data-name="sidebar" data-file="components/Sidebar.js">
        <div className="px-6 py-4 mb-8">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
              <div className="icon-building-2 text-xl text-[var(--primary-color)]"></div>
            </div>
            <div>
              <h1 className="text-xl font-bold">Mi Empresa</h1>
              <p className="text-xs text-blue-200">v1.0.0</p>
            </div>
          </div>
        </div>

        <nav className="px-3">
          {menuItems.map((item, index) => (
            <div key={index} className="mb-1">
              {item.submenu ? (
                <div>
                  <button onClick={() => toggleMenu(item.name)} className="w-full flex items-center justify-between px-4 py-3 rounded-lg hover:bg-white/10 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className={`icon-${item.icon} text-lg`}></div>
                      <span className="font-medium">{item.name}</span>
                    </div>
                    <div className={`icon-chevron-down text-sm transition-transform ${openMenus[item.name] ? 'rotate-180' : ''}`}></div>
                  </button>
                  {openMenus[item.name] && (
                    <div className="ml-8 mt-1 space-y-1">
                      {item.submenu.map((subitem, subindex) => (
                        <a key={subindex} href={subitem.link} className="block px-4 py-2 rounded-lg hover:bg-white/10 text-sm text-blue-100">
                          {subitem.name}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <a href={item.link} className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/10 transition-colors">
                  <div className={`icon-${item.icon} text-lg`}></div>
                  <span className="font-medium">{item.name}</span>
                </a>
              )}
            </div>
          ))}
        </nav>
      </div>
    );
  } catch (error) {
    console.error('Sidebar component error:', error);
    return null;
  }
}