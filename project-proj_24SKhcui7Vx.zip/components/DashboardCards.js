function DashboardCards() {
  try {
    const cards = [
      { title: 'Total Usuarios', value: '1,234', icon: 'users', color: 'blue', change: '+12%' },
      { title: 'Ingresos', value: '$45,678', icon: 'dollar-sign', color: 'green', change: '+8%' },
      { title: 'Proyectos', value: '89', icon: 'briefcase', color: 'purple', change: '+5%' },
      { title: 'Tareas Activas', value: '156', icon: 'check-square', color: 'orange', change: '-3%' }
    ];

    const colorClasses = {
      blue: { bg: 'bg-blue-100', icon: 'text-blue-600', text: 'text-blue-600' },
      green: { bg: 'bg-green-100', icon: 'text-green-600', text: 'text-green-600' },
      purple: { bg: 'bg-purple-100', icon: 'text-purple-600', text: 'text-purple-600' },
      orange: { bg: 'bg-orange-100', icon: 'text-orange-600', text: 'text-orange-600' }
    };

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8" data-name="dashboard-cards" data-file="components/DashboardCards.js">
        {cards.map((card, index) => (
          <div key={index} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${colorClasses[card.color].bg}`}>
                <div className={`icon-${card.icon} text-xl ${colorClasses[card.color].icon}`}></div>
              </div>
              <span className={`text-sm font-semibold ${card.change.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
                {card.change}
              </span>
            </div>
            <h3 className="text-gray-600 text-sm mb-1">{card.title}</h3>
            <p className="text-3xl font-bold text-gray-900">{card.value}</p>
          </div>
        ))}
      </div>
    );
  } catch (error) {
    console.error('DashboardCards component error:', error);
    return null;
  }
}