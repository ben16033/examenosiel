# Sistema de Administración

## Descripción
Sistema de administración web con control de roles de usuario, base de datos local y dashboard interactivo.

## Características Principales
- Login con efectos de cristalización (glassmorphism)
- Control de roles: Superusuario, Administrador, Usuario
- Base de datos local (LocalStorage)
- Dashboard con tarjetas estadísticas y gráficos
- Topbar con perfil de usuario
- Sidebar con menús desplegables

## Usuarios de Prueba
| Usuario | Contraseña | Rol |
|---------|-----------|-----|
| super1 | super123 | Superusuario |
| super2 | super123 | Superusuario |
| admin1 | admin123 | Administrador |
| admin2 | admin123 | Administrador |
| user1 | user123 | Usuario |
| user2 | user123 | Usuario |

## Estructura del Proyecto
- `index.html` - Página de login
- `dashboard.html` - Panel de control principal
- `components/` - Componentes React
- `utils/` - Utilidades (autenticación, base de datos)

## Tecnologías
- React 18
- TailwindCSS
- Chart.js
- Lucide Icons

## Versión
v1.0.0

© 2025 Sistema de Administración